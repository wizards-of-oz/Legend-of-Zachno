!#/bin/bash

python3 LegendofZachno.py
